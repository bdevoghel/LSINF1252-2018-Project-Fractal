# fractal_109_deVillenfagne_deVoghel
Code developed for the fractal multhreading project of the LSINF1252 course at the EPL

Academic year 2017-2018

USE (as example):
make tests
make rebuild
./main [-d] [--maxthreads 5] - 
        inputs/lvl0_exemple_�nonc�.txt o.bmp


Best way of testing the program is by using the few files found in input/
Don't hesitate to try to break the code using STDIN input, all possible input should be taken care of


Firsts commit (before 23-04-2018) deleted (caused by a forced push from CLion)


